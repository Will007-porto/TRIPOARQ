import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Database, 
  RotateCcw, 
  Check, 
  Lock, 
  Unlock, 
  Copy, 
  CheckCircle2,
  Droplet
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DB_CALIBRACAO } from './data';
import { TanqueConfig } from './types';

// Precise vector implementation of the corporate TRIPOARQ logo (white stylized T with diagonal sweeping swoosh on Navy background)
export function TripoarqLogo({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <div className={`relative rounded-xl bg-[#0a1e47] flex items-center justify-center overflow-hidden shrink-0 ${className} shadow-[0_4px_16px_rgba(0,0,0,0.5)] border border-blue-900/30`}>
      <svg 
        viewBox="0 0 100 100" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full p-1.5"
      >
        {/* White T base logo */}
        <g id="letter-t">
          {/* Top Bar of T */}
          <rect x="24" y="29" width="52" height="18" rx="2.5" fill="white" />
          {/* Vertical Stem of T */}
          <rect x="42" y="44" width="16" height="36" rx="2.5" fill="white" />
        </g>
        
        {/* Slicing swoosh curve (colored with the background blue to mask/cut the T) */}
        <path 
          d="M 31 71 C 32 50 49 34 90 23 C 62 33 47 52 46.5 82 C 45 77 39 74 31 71 Z" 
          fill="#0a1e47" 
        />
        
        {/* Overlay crescent sweep (White) for the continuous corporate swoosh line */}
        <path 
          d="M 31 71 C 41 45 59 34 90 23 C 67 33 49 52 48.5 81 C 47.5 76 39 74 31 71 Z" 
          fill="white" 
        />
      </svg>
    </div>
  );
}

export default function App() {
  // Configured preferences (localStorage)
  const [selectedObraId, setSelectedObraId] = useState<string>('');
  const [selectedTanqueId, setSelectedTanqueId] = useState<string>('');
  const [isFirstSetup, setIsFirstSetup] = useState<boolean>(false);
  
  // Secret unlock state for changing "Obra" (5 silent clicks)
  const [unlockClicks, setUnlockClicks] = useState<number>(0);
  const [obraSelectorUnlocked, setObraSelectorUnlocked] = useState<boolean>(false);
  const [tempObraId, setTempObraId] = useState<string>('');
  const [tempTanqueId, setTempTanqueId] = useState<string>('');
  
  // Onboarding setup state
  const [setupObraId, setSetupObraId] = useState<string>('obra_pitanga');
  const [setupTanqueId, setSetupTanqueId] = useState<string>('CL_0021');

  // Ruler numeric inputs
  const [medidasInput, setMedidasInput] = useState<{ [index: number]: string }>({ 0: '', 1: '' });
  const [calculatedVolume, setCalculatedVolume] = useState<number>(0);
  const [hasError, setHasError] = useState<string>('');
  const [allEmpty, setAllEmpty] = useState<boolean>(true);

  // User interactions feedback
  const [copied, setCopied] = useState<boolean>(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Load sticky defaults on boot
  useEffect(() => {
    try {
      const savedObra = localStorage.getItem('defaultObra');
      const savedTanque = localStorage.getItem('defaultTanque');
      if (savedObra && DB_CALIBRACAO[savedObra]) {
        setSelectedObraId(savedObra);
        setIsFirstSetup(false);
        if (savedTanque && DB_CALIBRACAO[savedObra].tanques[savedTanque]) {
          setSelectedTanqueId(savedTanque);
        } else {
          setSelectedTanqueId(Object.keys(DB_CALIBRACAO[savedObra].tanques)[0]);
        }
      } else {
        // App opened for the first time: Force Onboarding preference screen
        setIsFirstSetup(true);
      }
    } catch (e) {
      console.error('Failed to parse localStorage device settings', e);
      setIsFirstSetup(true);
    }
  }, []);

  // Display a brief non-intrusive toast notification
  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  // Secret unlock mechanism (Increments silently without hinting or informing)
  const handleBadgeClick = () => {
    if (obraSelectorUnlocked) {
      showToast('A alteração de obra já está liberada!', 'info');
      return;
    }
    const nextClicks = unlockClicks + 1;
    setUnlockClicks(nextClicks);
    
    if (nextClicks >= 5) {
      setObraSelectorUnlocked(true);
      setTempObraId(selectedObraId);
      setTempTanqueId(selectedTanqueId);
      setUnlockClicks(0);
      showToast('🔓 Escolha de obra liberada para alteração.', 'success');
    }
  };

  // Change active Tank (Freely changeable within the configured Obra scope. Persists immediately as starting default)
  const handleTanqueChange = (tanqueId: string) => {
    setSelectedTanqueId(tanqueId);
    setMedidasInput({ 0: '', 1: '' });
    localStorage.setItem('defaultTanque', tanqueId);
  };

  // Linear Interpolation algorithm
  const doInterpolation = (medValue: number, table: number[]): number => {
    const base = Math.floor(medValue);
    if (base >= table.length - 1) {
      return table[table.length - 1];
    }
    const frac = medValue - base;
    return table[base] + frac * (table[base + 1] - table[base]);
  };

  // Calculate volume result dynamically on any measurement changes
  useEffect(() => {
    if (!selectedObraId || !selectedTanqueId) return;
    const activeObra = DB_CALIBRACAO[selectedObraId];
    if (!activeObra) return;
    const activeTanque = activeObra.tanques[selectedTanqueId];
    if (!activeTanque) return;

    let totalVolume = 0;
    let isAllEmpty = true;
    let errorMsg = '';

    const indexes = activeTanque.tipo === 'simples' ? [0] : [0, 1];

    for (const idx of indexes) {
      const inputVal = medidasInput[idx]?.trim() || '';
      if (inputVal !== '') {
        isAllEmpty = false;
        const parsedVal = parseFloat(inputVal.replace(',', '.'));
        const maxLimit = activeTanque.tipo === 'simples' 
          ? activeTanque.max 
          : activeTanque.compartimentos[idx].max;

        if (isNaN(parsedVal)) {
          errorMsg = 'Medida inválida informada.';
          break;
        } else if (parsedVal < 0) {
          errorMsg = 'A régua não pode ser negativa.';
          break;
        } else if (parsedVal > maxLimit) {
          const compName = activeTanque.tipo === 'simples' ? 'Tanque' : activeTanque.compartimentos[idx].nome;
          errorMsg = `Limite de ${maxLimit} cm excedido no ${compName}.`;
          break;
        } else {
          const table = activeTanque.tipo === 'simples' 
            ? activeTanque.tabela 
            : activeTanque.compartimentos[idx].tabela;
          
          totalVolume += doInterpolation(parsedVal, table);
        }
      }
    }

    setAllEmpty(isAllEmpty);
    setHasError(errorMsg);
    setCalculatedVolume(isAllEmpty || errorMsg ? 0 : totalVolume);
  }, [medidasInput, selectedObraId, selectedTanqueId]);

  const activeObra = selectedObraId ? DB_CALIBRACAO[selectedObraId] : null;
  const activeTanque = activeObra && selectedTanqueId ? activeObra.tanques[selectedTanqueId] : null;

  // Calculate total max capacity of the current active tank for the fuel animation percentage
  const getMaxCapacity = (): number => {
    if (!activeTanque) return 10000;
    if (activeTanque.tipo === 'simples') {
      return activeTanque.tabela[activeTanque.tabela.length - 1] || 10000;
    } else {
      const c1 = activeTanque.compartimentos[0];
      const c2 = activeTanque.compartimentos[1];
      const maxC1 = c1.tabela[c1.tabela.length - 1] || 5000;
      const maxC2 = c2.tabela[c2.tabela.length - 1] || 5000;
      return maxC1 + maxC2;
    }
  };

  const totalMaxCapacity = getMaxCapacity();
  const fillPercent = calculatedVolume > 0 && totalMaxCapacity > 0 
    ? Math.min(1, calculatedVolume / totalMaxCapacity) 
    : 0;

  // Copy parsed volume output directly (without the "L" or any extra characters)
  const handleCopyToClipboard = () => {
    if (allEmpty || hasError) return;
    const cleanNumericString = calculatedVolume.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
    navigator.clipboard.writeText(cleanNumericString)
      .then(() => {
        setCopied(true);
        showToast('Volume copiado com sucesso!', 'success');
        setTimeout(() => setCopied(false), 2000);
      })
      .catch((err) => {
        console.error('Falha ao copiar valor', err);
        showToast('Erro ao copiar volume.', 'error');
      });
  };

  return (
    <div className="min-h-screen bg-[#06080c] text-gray-100 flex flex-col items-center justify-center font-sans relative antialiased select-none p-4 overflow-hidden">
      
      {/* Decorative clean radial glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] sm:w-[500px] h-[350px] sm:h-[500px] bg-amber-500/[0.04] rounded-full blur-[110px] pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-44 h-44 bg-blue-500/[0.02] rounded-full blur-[90px] pointer-events-none" />

      {/* Global alert / Toast notifications */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: -40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className={`fixed top-5 z-[250] px-3.5 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 border text-xs font-semibold ${
              toast.type === 'success' 
                ? 'bg-emerald-950/95 border-emerald-500/20 text-emerald-300' 
                : toast.type === 'error'
                ? 'bg-rose-950/95 border-rose-500/20 text-rose-300'
                : 'bg-zinc-900/95 border-zinc-800 text-zinc-300'
            }`}
          >
            <div className={`w-1.5 h-1.5 rounded-full ${
              toast.type === 'success' ? 'bg-emerald-400' : toast.type === 'error' ? 'bg-rose-400' : 'bg-amber-400'
            }`} />
            <span>{toast.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        {isFirstSetup ? (
          /* ============================================================ */
          /* INITIAL SETUP VIEW (ONBOARDING PORTAL - ONLY RUNS ONCE)      */
          /* ============================================================ */
          <motion.div
            key="onboarding"
            initial={{ opacity: 0, scale: 0.97, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -15 }}
            transition={{ duration: 0.35, ease: 'easeOut' }}
            className="w-full max-w-sm bg-[#0a0d14]/90 backdrop-blur-xl border border-zinc-850 rounded-2xl p-6 sm:p-7 shadow-[0_24px_60px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col relative"
          >
            {/* Ambient decorative bar */}
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-amber-600 via-amber-400 to-yellow-300/40" />

            <div className="flex items-center gap-3 mb-5 pb-4 border-b border-zinc-800">
              <TripoarqLogo className="w-10 h-10" />
              <div>
                <h2 className="text-sm font-extrabold text-gray-200 tracking-tight leading-none mb-1">TRIPOARQ</h2>
                <span className="text-[10px] text-zinc-500 uppercase tracking-wider font-semibold">Configuração de Dispositivo</span>
              </div>
            </div>

            <p className="text-xs text-zinc-400 mb-6 leading-relaxed bg-zinc-950/45 p-3 rounded-xl border border-zinc-850 font-medium">
              Antes de iniciar, preestabeleça a sua <strong className="text-amber-400 font-semibold font-mono">Obra de Trabalho</strong> e seu <strong className="text-amber-400 font-semibold font-mono font-sans">Tanque Preferencial</strong>. Por motivos de segurança operacional, a escolha de obra ficará travada na inicialização do sistema.
            </p>

            <div className="space-y-4 mb-6">
              {/* Setup Obra Dropdown */}
              <div>
                <label className="block text-[10px] font-bold text-zinc-500 mb-1.5 uppercase tracking-widest">
                  Selecione a Obra de Operação
                </label>
                <select
                  value={setupObraId}
                  onChange={(e) => {
                    setSetupObraId(e.target.value);
                    const defaultTanqueForThisObra = Object.keys(DB_CALIBRACAO[e.target.value].tanques)[0];
                    setSetupTanqueId(defaultTanqueForThisObra);
                  }}
                  className="w-full bg-[#11141c] border border-zinc-800 hover:border-zinc-700 rounded-xl px-3.5 py-3 text-xs text-zinc-100 font-bold outline-none focus:border-amber-500/50 focus:ring-1 focus:ring-amber-500/20 transition-all cursor-pointer"
                >
                  {Object.entries(DB_CALIBRACAO).map(([id, item]) => (
                    <option key={id} value={id}>
                      {item.nome}
                    </option>
                  ))}
                </select>
              </div>

              {/* Setup Tanque Dropdown */}
              <div>
                <label className="block text-[10px] font-bold text-zinc-500 mb-1.5 uppercase tracking-widest">
                  Selecione o Tanque Principal
                </label>
                <select
                  value={setupTanqueId}
                  onChange={(e) => setSetupTanqueId(e.target.value)}
                  className="w-full bg-[#11141c] border border-zinc-800 hover:border-zinc-700 rounded-xl px-3.5 py-3 text-xs text-zinc-100 font-bold outline-none focus:border-amber-500/50 focus:ring-1 focus:ring-amber-500/20 transition-all cursor-pointer"
                >
                  {Object.entries(DB_CALIBRACAO[setupObraId].tanques).map(([id, item]) => (
                    <option key={id} value={id}>
                      {item.nome}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <button
              onClick={() => {
                localStorage.setItem('defaultObra', setupObraId);
                localStorage.setItem('defaultTanque', setupTanqueId);
                setSelectedObraId(setupObraId);
                setSelectedTanqueId(setupTanqueId);
                setMedidasInput({ 0: '', 1: '' });
                setIsFirstSetup(false);
                showToast('✨ Configuração gravada! Terminal de medição iniciado com sucesso.', 'success');
              }}
              className="w-full bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-600 hover:to-amber-500 text-[#06080c] font-black py-3.5 px-4 rounded-xl text-xs sm:text-sm tracking-wide transition-all shadow-xl active:scale-[0.98] flex items-center justify-center gap-1.5"
            >
              <Check className="w-4 h-4 stroke-[2.5]" />
              Gravar Configurações
            </button>
          </motion.div>
        ) : (
          /* ============================================================ */
          /* MAIN SINGLE-WINDOW INTERACTIVE CALIBRATOR INTERFACE          */
          /* ============================================================ */
          <motion.div
            key="calibrator"
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-sm bg-[#090b11]/95 backdrop-blur-xl border border-zinc-850 rounded-2xl shadow-[0_24px_60px_rgba(0,0,0,0.95)] overflow-hidden flex flex-col relative z-10 transition-all"
          >
            
            {/* Ambient subtle glowing indicator */}
            <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-amber-500/75 via-amber-400/50 to-amber-500/25 w-full" />

            {/* Smart Minimal Header */}
            <div className="px-4.5 py-3.5 border-b border-zinc-900 flex items-center justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <TripoarqLogo className="w-7.5 h-7.5" />
                <div className="min-w-0">
                  <span className="text-xs font-extrabold text-zinc-100 tracking-wider block leading-none">TRIPOARQ</span>
                </div>
              </div>
              
              {/* Stealth click element - totally secret, no instructions or help texts */}
              <button 
                onClick={handleBadgeClick}
                className="px-2 py-0.5 text-[9.5px] uppercase font-bold tracking-wider rounded bg-zinc-950 border border-zinc-850 text-zinc-500 hover:text-zinc-400 hover:bg-zinc-900 active:scale-95 transition-all outline-none"
              >
                Calibração Pro
              </button>
            </div>

            {/* Main Interactive Controls Wrapper */}
            {activeObra && activeTanque && (
              <div className="p-4.5 flex-1 flex flex-col space-y-4">
                
                {/* Active Obra Display Box (Locked normally, switches to clean select only if unlocked) */}
                <div className="bg-zinc-950/40 border border-zinc-900 rounded-xl p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-widest">Obra de Operação</span>
                    <div className="flex items-center gap-1">
                      {obraSelectorUnlocked ? (
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      ) : (
                        <Lock className="w-3 h-3 text-zinc-600" />
                      )}
                    </div>
                  </div>

                  {obraSelectorUnlocked ? (
                    <div className="space-y-3 p-2 bg-[#090b10] rounded-xl border border-emerald-500/25">
                      <div>
                        <label className="block text-[8px] font-extrabold text-[#11b981] uppercase tracking-widest mb-1">
                          Selecione a Nova Obra
                        </label>
                        <select
                          value={tempObraId}
                          onChange={(e) => {
                            setTempObraId(e.target.value);
                            const firstTan = Object.keys(DB_CALIBRACAO[e.target.value].tanques)[0];
                            setTempTanqueId(firstTan);
                          }}
                          className="w-full bg-[#11141c] border border-zinc-800 rounded-lg px-2.5 py-1.5 text-xs text-zinc-200 font-bold outline-none focus:border-emerald-500/50"
                        >
                          {Object.entries(DB_CALIBRACAO).map(([id, item]) => (
                            <option key={id} value={id}>
                              {item.nome}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[8px] font-extrabold text-[#11b981] uppercase tracking-widest mb-1">
                          Selecione o Tanque Padrão
                        </label>
                        <select
                          value={tempTanqueId}
                          onChange={(e) => setTempTanqueId(e.target.value)}
                          className="w-full bg-[#11141c] border border-zinc-800 rounded-lg px-2.5 py-1.5 text-xs text-zinc-200 font-bold outline-none focus:border-emerald-500/50"
                        >
                          {Object.entries(DB_CALIBRACAO[tempObraId]?.tanques || {}).map(([id, item]) => (
                            <option key={id} value={id}>
                              {item.nome}
                            </option>
                          ))}
                        </select>
                      </div>

                      <button
                        onClick={() => {
                          setSelectedObraId(tempObraId);
                          setSelectedTanqueId(tempTanqueId);
                          setMedidasInput({ 0: '', 1: '' });
                          
                          // Persist both immediately in standard storage
                          localStorage.setItem('defaultObra', tempObraId);
                          localStorage.setItem('defaultTanque', tempTanqueId);
                          
                          setObraSelectorUnlocked(false);
                          showToast('Obra e tanque padrão sincronizados!', 'success');
                        }}
                        className="w-full bg-[#10b981] hover:bg-[#059669] text-zinc-950 text-[10px] font-black py-2 rounded-lg transition-all active:scale-[0.98] uppercase tracking-wider block text-center"
                      >
                        Salvar Nova Obra & Padrão
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                      <span className="text-xs font-bold text-zinc-200 truncate">{activeObra.nome}</span>
                    </div>
                  )}

                  {/* Active Tank Dropdown */}
                  {!obraSelectorUnlocked && (
                    <div className="pt-2.5 border-t border-zinc-900/60 mt-1.5 flex flex-col gap-1">
                      <label className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-widest">Equipamento / Tanque</label>
                      <select
                        value={selectedTanqueId}
                        onChange={(e) => handleTanqueChange(e.target.value)}
                        className="w-full bg-[#080a0f]/80 border border-zinc-850 rounded-lg px-2 py-1.5 text-xs font-bold text-zinc-200 outline-none focus:border-amber-500/50 transition-colors"
                      >
                        {Object.entries(activeObra.tanques).map(([id, item]) => (
                          <option key={id} value={id}>
                            {item.nome}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>

                {/* Ruler Levels User Inputs Area */}
                <div className="space-y-1.5">
                  <span className="block text-[9px] font-extrabold text-amber-500 uppercase tracking-widest pl-0.5">Leitura de régua (cm)</span>
                  
                  {activeTanque.tipo === 'simples' ? (
                    <div className="relative">
                      <input
                        type="text"
                        value={medidasInput[0] || ''}
                        inputMode="decimal"
                        onChange={(e) => setMedidasInput({ ...medidasInput, 0: e.target.value })}
                        placeholder="Insira a medida"
                        className="w-full bg-[#0d1017] border border-zinc-850 rounded-xl px-4 py-3.5 text-2xl font-mono font-bold text-amber-500 hover:border-zinc-800 focus:border-amber-500/50 text-center outline-none transition-all placeholder:text-zinc-800 placeholder:text-lg placeholder:font-sans"
                        autoFocus
                      />
                      <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none flex flex-col items-end">
                        <span className="text-xs font-extrabold text-zinc-500 font-mono leading-none">cm</span>
                        <span className="text-[9px] font-bold text-zinc-600 leading-none mt-0.5">Máx: {activeTanque.max}cm</span>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-2.5">
                      {/* Bipartido Compartment 1 input */}
                      <div className="relative">
                        <input
                          type="text"
                          value={medidasInput[0] || ''}
                          inputMode="decimal"
                          onChange={(e) => setMedidasInput({ ...medidasInput, 0: e.target.value })}
                          placeholder="DIANT."
                          className="w-full bg-[#0d1017] border border-zinc-850 rounded-xl px-2.5 py-3 text-xl font-mono font-bold text-amber-500 hover:border-zinc-800 focus:border-amber-500/50 text-center outline-none transition-all placeholder:text-zinc-800 placeholder:text-sm placeholder:font-sans"
                          autoFocus
                        />
                        <div className="absolute right-2.5 bottom-1 pointer-events-none text-[8px] font-bold text-zinc-600 leading-none font-mono">
                          M: {activeTanque.compartimentos[0].max}cm
                        </div>
                      </div>

                      {/* Bipartido Compartment 2 input */}
                      <div className="relative">
                        <input
                          type="text"
                          value={medidasInput[1] || ''}
                          inputMode="decimal"
                          onChange={(e) => setMedidasInput({ ...medidasInput, 1: e.target.value })}
                          placeholder="TRAS."
                          className="w-full bg-[#0d1017] border border-zinc-850 rounded-xl px-2.5 py-3 text-xl font-mono font-bold text-amber-500 hover:border-zinc-800 focus:border-amber-500/50 text-center outline-none transition-all placeholder:text-zinc-800 placeholder:text-sm placeholder:font-sans"
                        />
                        <div className="absolute right-2.5 bottom-1 pointer-events-none text-[8px] font-bold text-zinc-600 leading-none font-mono">
                          M: {activeTanque.compartimentos[1].max}cm
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Operational error boundary messages */}
                  {hasError && (
                    <p className="text-[10px] font-bold text-rose-400 text-center p-1.5 bg-rose-950/15 border border-rose-500/20 rounded-lg animate-pulse leading-snug">
                      {hasError}
                    </p>
                  )}
                </div>

                {/* Highly Immersive Liquid Filling Container Card */}
                <div className="pt-1.5">
                  <div className="bg-[#0b0e15] border border-zinc-900 rounded-2xl p-5 shadow-inner flex flex-col items-center justify-center relative overflow-hidden h-[135px] transition-all">
                    
                    {/* Animated Liquid Background Layer (Rising dynamically, styled to appear as fluid) */}
                    <div 
                      className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-amber-600/35 via-amber-500/25 to-amber-500/5 pointer-events-none transition-all duration-700 ease-out animate-fluid"
                      style={{ height: `${fillPercent * 100}%` }}
                    />

                    {/* Styled Wave overlays */}
                    {fillPercent > 0 && (
                      <div 
                        className="absolute left-0 right-0 bg-amber-500/10 h-1 sm:h-1.5 opacity-40 blur-[1px] pointer-events-none transition-all duration-700 ease-out"
                        style={{ bottom: `calc(${fillPercent * 100}% - 1px)` }}
                      />
                    )}

                    {/* Rising Bubble Particles */}
                    {fillPercent > 0 && (
                      <>
                        <div className="bubble-particle" style={{ left: '12%', width: '5px', height: '5px', animationDelay: '0s', animationDuration: '3.5s' }} />
                        <div className="bubble-particle" style={{ left: '38%', width: '3px', height: '3px', animationDelay: '1.2s', animationDuration: '2.2s' }} />
                        <div className="bubble-particle" style={{ left: '60%', width: '7px', height: '7px', animationDelay: '0.5s', animationDuration: '4.5s' }} />
                        <div className="bubble-particle" style={{ left: '85%', width: '4px', height: '4px', animationDelay: '2.1s', animationDuration: '3s' }} />
                      </>
                    )}

                    {/* Static Container Frame lines */}
                    <div className="absolute inset-x-0 top-0 h-[1.5px] bg-zinc-900/60" />
                    
                    {/* Text values centered on top of liquid */}
                    <div className="relative z-10 text-center select-text">
                      <span className="text-[8.5px] font-extrabold text-amber-500 uppercase tracking-widest block mb-1">
                        Volume Resultante
                      </span>
                      
                      {allEmpty ? (
                        <h2 className="text-3xl font-black text-zinc-700 font-mono tracking-tight leading-none">
                          0,00 L
                        </h2>
                      ) : hasError ? (
                        <h2 className="text-2xl font-black text-rose-500/95 leading-none uppercase tracking-wider">
                          Aguardando...
                        </h2>
                      ) : (
                        <motion.h2 
                          key={calculatedVolume}
                          initial={{ scale: 0.96 }}
                          animate={{ scale: 1 }}
                          className="text-4xl font-extrabold text-amber-400 font-mono tracking-tighter leading-none break-all"
                        >
                          {calculatedVolume.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} <span className="text-xl font-sans tracking-normal font-extrabold text-amber-500 leading-none">L</span>
                        </motion.h2>
                      )}

                      {!allEmpty && !hasError && (
                        <span className="text-[8px] text-zinc-500 uppercase font-mono tracking-wider font-extrabold mt-1 block">
                          {(fillPercent * 100).toFixed(1)}% preenchido
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Action commands (Discrete buttons for Copy and Reset fields) */}
                <div className="pt-1 space-y-2">
                  <button
                    onClick={handleCopyToClipboard}
                    disabled={allEmpty || !!hasError}
                    className={`w-full py-3 px-4 rounded-xl text-xs font-black transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer 
                      ${allEmpty || hasError 
                        ? 'bg-zinc-950 text-zinc-700 border border-zinc-900 cursor-not-allowed' 
                        : 'bg-zinc-900 hover:bg-zinc-850 hover:text-white text-zinc-200 border border-zinc-800 hover:border-zinc-700 active:scale-[0.99]'
                      }`}
                  >
                    {copied ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>Copiado sem unidade</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-zinc-500" />
                        <span>Copiar Volume (Número)</span>
                      </>
                    )}
                  </button>

                  {!allEmpty && (
                    <button
                      onClick={() => setMedidasInput({ 0: '', 1: '' })}
                      className="w-full py-1.5 hover:bg-zinc-950 text-[10px] font-extrabold text-zinc-600 hover:text-zinc-400 uppercase tracking-widest transition-all flex items-center justify-center gap-1"
                    >
                      <RotateCcw className="w-3 h-3" />
                      Limpar Atuais
                    </button>
                  )}
                </div>

              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Discrete Reset Preference trigger block (Requires lock-free choice confirmation) */}
      {!isFirstSetup && (
        <div className="mt-4 z-10 opacity-40 hover:opacity-100 transition-opacity duration-300">
          <button 
            onClick={() => {
              if (window.confirm('Deseja resetar o padrão de início para realizar uma nova pré-seleção total?')) {
                localStorage.removeItem('defaultObra');
                localStorage.removeItem('defaultTanque');
                setSelectedObraId('');
                setSelectedTanqueId('');
                setMedidasInput({ 0: '', 1: '' });
                setIsFirstSetup(true);
                showToast('Preferências de início limpas de fábrica', 'info');
              }
            }}
            className="flex items-center gap-1.5 text-zinc-600 hover:text-zinc-400 text-[10px] font-bold uppercase tracking-wider bg-transparent border-none px-2 py-1 transition-all outline-none"
          >
            Configurar padrão inicial
          </button>
        </div>
      )}
    </div>
  );
}
