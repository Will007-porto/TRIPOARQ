/**
 * Types and interfaces for Arqueação Corporativa
 */

export interface Compartimento {
  nome: string;
  max: number; // Max level in cm
  tabela: number[]; // Capacity lookup table by centimetre
}

export type TanqueTipo = 'simples' | 'duplo';

export interface TanqueSimples {
  tipo: 'simples';
  nome: string;
  max: number; // Max level in cm
  tabela: number[];
}

export interface TanqueDuplo {
  tipo: 'duplo';
  nome: string;
  compartimentos: Compartimento[];
}

export type TanqueConfig = TanqueSimples | TanqueDuplo;

export interface ObraConfig {
  nome: string;
  tanques: {
    [tanqueId: string]: TanqueConfig;
  };
}

export interface DatabaseConfig {
  [obraId: string]: ObraConfig;
}

export interface MedicaoRecord {
  id: string;
  data: string;
  obraId: string;
  obraNome: string;
  tanqueId: string;
  tanqueNome: string;
  medidas: string; // Formatting e.g. "120 cm" or "120 cm / 95 cm"
  litros: string;  // E.g. "15.420,50 L"
  litrosValor: number;
}
