package com.arqueacao.corporativa;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
